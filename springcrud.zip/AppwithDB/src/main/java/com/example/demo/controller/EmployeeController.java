package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Employee;
import com.example.demo.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	@Autowired
	private EmployeeService employeeservice;
	
	
	@GetMapping("/all")
	
	public List<Employee> getAllEmployees(){
		return employeeservice.getAllEmployees();
		
	}
	
	@PostMapping("/add")
	public Employee addEmployee(@RequestBody Employee e) {
		return employeeservice.addEmployee(e);
		
	}
	
	@DeleteMapping("/delete/{id}")
	public void deleteEmployee(@PathVariable int id) {
		employeeservice.deleteEmployee(id);
	}
	@PutMapping("/update/{id}")                                    //for update
	public Employee updateEmployee(@PathVariable int id,@RequestBody Employee e) {
		
		return employeeservice.updateEmployee(e, id);
	}
	@GetMapping("/search/{id}")
	public Optional<Employee> findById(@PathVariable int id){
		return employeeservice.findbyId(id);

}
}
