package com.example.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.entity.Employee;
import com.example.demo.repository.EmployeeRepository;

@Service
public class EmployeeService {
	@Autowired // to access the methods in service class by controller class
	private  EmployeeRepository employeeRepository;

	public List<Employee> getAllEmployees() {
		return employeeRepository.findAll();

	}

	public Employee addEmployee(Employee e) {
		return employeeRepository.save(e);
	}
	
	public void deleteEmployee(int id) {
		employeeRepository.deleteById(id);
	}
	public Employee updateEmployee(Employee e, int id) {
		e.setId(id);
		return employeeRepository.save(e);

}
	public Optional<Employee> findbyId( int id){
		return this.employeeRepository.findById(id);
	}
}
