package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;

@Entity
@NamedQuery(name="Employee.findbyId", query="select em from Employee em where em.id=:id")
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	int id;
	String ename;
	boolean esalary;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEname() {
		return ename;
	}
	public void setEname(String ename) {
		this.ename = ename;
	}
	public boolean isEsalary() {
		return esalary;
	}
	public void setEsalary(boolean esalary) {
		this.esalary = esalary;
	}
	public Employee(int id, String ename, boolean esalary) {
		super();
		this.id = id;
		this.ename = ename;
		this.esalary = esalary;
	}
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
