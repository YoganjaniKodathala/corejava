package withdatabase.entity;

public class Product {

}
